<div class="breadcrumb_dress">
		<div class="container">
			<ul>
				<li><a href="index.php?route=home"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
				<li>Konfirmasi Pembayaran</li>
			</ul>
		</div>
	</div>
<div class="team-bottom">
		<div class="container">
			<h3>Konfirmasi Pembayaran</h3>
			<p>Terima Kasih.
Konfirmasi Pembayaran telah dikirim ke pengelola. 
Order Anda akan segera kami proses dengan amanh dan tanggung jawab penuh</p>
			<a href="index.php?route=home">Lanjutkan</a>
		</div>
	</div>