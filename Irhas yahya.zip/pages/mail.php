<div class="banner10" id="home1">
		<div class="container">
			<h2>Hubungi Kami</h2>
		</div>
	</div>
<!-- //banner -->

<!-- breadcrumbs -->
	<div class="breadcrumb_dress">
		<div class="container">
			<ul>
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
				<li>Hubungi Kami</li>
			</ul>
		</div>
	</div>
<!-- //breadcrumbs -->

<!-- mail -->
	<div class="mail">
		<div class="container">
			<h3>Hubungi Kami</h3>
			<div class="agile_mail_grids">
				<div class="col-md-5 contact-left">
					<h4>Alamat</h4>
					<p>Febryahya Fasion
						<span>Demak</span></p>
					<ul>
						
						<li>Telepon : (+62)89657221897</li>
						
						<li><a href="mailto:shafiyya@shafiyyahfashion.com">febryahya@febryahyafasion.com</a></li>
					</ul>
				</div>
				<div class="col-md-7 contact-left">
					<h4>Contact me</h4>
					<form action="#" method="post">
						<input type="text" name="Name" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}" required="">
						<input type="email" name="Email" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" required="">
						<input type="text" name="Telephone" value="Telephone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Telephone';}" required="">
						<textarea name="message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message...';}" required="">Message...</textarea>
						<input type="submit" value="Submit" >
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>

			
		</div>
	</div>