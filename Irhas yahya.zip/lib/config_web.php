<?php
$web_url = "http://localhost/projek1/";
$admin_url = "http://localhost/projek1/adminpages/";
?>