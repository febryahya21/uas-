<?php
$host = "localhost";
$username = "root";
$password = "";
$database_name = "olshop";

$koneksi = mysqli_connect($host, $username, $password, $database_name) or die ("Koneksi Gagal");

?>