<?php
include "templates/header.php";
include "pages/cariproduk.php";
include "templates/footer.php";
?>