<?php
session_start();
include "templates/header.php";
include "pages/pemberitahuan2.php";
include "templates/footer.php";
?>