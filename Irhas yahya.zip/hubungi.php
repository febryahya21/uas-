<?php
session_start();
include "templates/header.php";
include "pages/mail.php";
include "templates/footer.php";
?>