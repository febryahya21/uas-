<?php
session_start();
include "templates/header.php";
include "pages/confirm.php";
include "templates/footer.php";
?>