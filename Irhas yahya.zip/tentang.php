<?php
session_start();
include "templates/header.php";
include "pages/about.php";
include "templates/footer.php";
?>