<?php
session_start();
include "templates/header.php";
include "terimakasih.php";
include "templates/footer.php";
?>