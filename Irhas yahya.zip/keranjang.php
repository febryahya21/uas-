<?php
session_start();
include "templates/header.php";
include "pages/cart.php";
include "templates/footer.php";
?>